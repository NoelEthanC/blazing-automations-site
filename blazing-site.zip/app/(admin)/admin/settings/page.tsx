import { AdminSettings } from "@/components/admin/admin-settings"

export default function SettingsPage() {
  return <AdminSettings />
}
