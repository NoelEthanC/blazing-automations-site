import { ContentManagement } from "@/components/admin/content-management"

export default function ContentManagementPage() {
  return <ContentManagement />
}
